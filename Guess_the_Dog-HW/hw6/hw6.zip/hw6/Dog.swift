//
//  Dog.swift
//  hw6
//
//  Created by Andy Huang on 3/8/23.
//

import Foundation

/* This is a model or "blueprint" for the JSON data that we will receive from the api! */
struct Dog: Codable {
    // TODO: Part 2a - Define model for JSON.
   let message: String
   let status: String
//   init(imgURL: String, breed: String) {
//      self.imgURL = imgURL
//      self.breed = breed
//   }
}
