//
//  hw8App.swift
//  hw8
//
//  Created by Andy Huang on 3/31/23.
//

import SwiftUI

@main
struct hw8App: App {
    var body: some Scene {
        WindowGroup {
            q3()
        }
    }
}
