//
//  HW72App.swift
//  HW72
//
//  Created by Abinaya on 3/21/23.
//

import SwiftUI

@main
struct HW72App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
